import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="trexplot",
    version="1",
    author="Hamish Robertson",
    author_email="h(dot)alastair(dot)r@gmail.com",
    description="Fat package with plotting scriptz! Mad vibes!",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/hammytheham/trexplot",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
