# Welcome to trexplot

We aim to deliver a lo-fi plotting experience to Toughreactmech output files.

## To install

`pip install whatever-its-called`
